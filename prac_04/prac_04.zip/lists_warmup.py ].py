"""
numbers[0]=3
numbers[-1]=2
numbers[3]=1
numbers[:-1]
numbers[3:4]
5 in numbers
7 in numbers
"3" in numbers
numbers + [6, 5, 3]
"""

numbers = [3, 1, 4, 1, 5, 9, 2]
number[0]="ten"
number[-1]=1
numbers(2:)
9 in numbers

